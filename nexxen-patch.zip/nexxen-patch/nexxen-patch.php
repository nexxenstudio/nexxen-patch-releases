<?php
/**
 * Plugin Name: Nexxen Patch
 * Plugin URI: https://nexxenstudio.com/
 * Description: Fixes visual defects that admin-theme and framework plugins cause in wp-admin (currently: uiXpress + Core Framework conflicts). Each fix is a toggle under Settings → Nexxen Patch; all fixes are on by default. Fixes live here so they survive updates of the plugins they patch.
 * Version: 1.2.9
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: Nexxen Studio
 * Author URI: https://nexxenstudio.com/
 * License: GPL-2.0-or-later
 * Text Domain: nexxen-patch
 */

defined( 'ABSPATH' ) || exit;

define( 'NEXXEN_PATCH_VERSION', '1.2.9' );
define( 'NEXXEN_PATCH_FILE', __FILE__ );

require_once __DIR__ . '/src/Updater.php';

add_action( 'plugins_loaded', static function () {
	Nexxen_Patch_Plugin::instance()->boot();
}, 5 );

final class Nexxen_Patch_Plugin {

	const OPTION = 'nexxen_patch_disabled'; // Array of fix ids the operator switched OFF.

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * The fix registry. Adding a future fix = one entry here plus its CSS in
	 * print_fix_css() (or a scoped hook). Everything is admin-only; nothing in
	 * this plugin ever loads on the public front end.
	 */
	public function fixes() {
		return array(
			'core-framework-reset-clash' => array(
				'label'       => __( 'Repair uiXpress on screens with clashing vendor CSS', 'nexxen-patch' ),
				'description' => __( 'Some plugins (Core Framework, Squirrly SEO) ship global CSS that flattens or decorates uiXpress\'s layered styles — collapsing the sidebar or drawing boxes around menu items. This restores the layered styles inside uiXpress containers on those screens. Filter nexxen_patch_reset_clash_screens to add offenders.', 'nexxen-patch' ),
			),
			'notice-polish'              => array(
				'label'       => __( 'Readable buttons in admin notices', 'nexxen-patch' ),
				'description' => __( 'Action buttons inside notice banners (for example TranslatePress\'s "Start optimization") could render dark-on-dark and unreadable. This gives notice buttons one consistent, readable style.', 'nexxen-patch' ),
			),
			'topbar-tidy'                => array(
				'label'       => __( 'Tidy the top toolbar', 'nexxen-patch' ),
				'description' => __( 'Third-party toolbar items wrap onto two lines at uneven heights and inconsistent spacing inside the uiXpress top bar. This gives every item one line, one height, the same padding and the same hover.', 'nexxen-patch' ),
			),
			'topbar-dropdowns'           => array(
				'label'       => __( 'Fix toolbar dropdown menus', 'nexxen-patch' ),
				'description' => __( 'Toolbar dropdowns (WPvivid, TranslatePress, Squirrly…) opened on top of the bar itself, covering their own trigger. They now open below the bar as a proper menu card, with nested submenus opening to the side.', 'nexxen-patch' ),
			),
			'logo-rounding'              => array(
				'label'       => __( 'Round the sidebar logo', 'nexxen-patch' ),
				'description' => __( 'The site icon in the sidebar header renders as a hard square. This rounds its corners to match the rest of the interface.', 'nexxen-patch' ),
			),
			'topbar-icons'               => array(
				'label'       => __( 'Repair toolbar icons and chips', 'nexxen-patch' ),
				'description' => __( 'Pins toolbar plugin icons (Bricks…) to a crisp square so they cannot distort, renders the command-palette shortcut as a proper keyboard chip instead of bare text, and removes the stray background on the search button.', 'nexxen-patch' ),
			),
			'plugin-page-palette'        => array(
				'label'       => __( 'Neutral palette on plugin pages', 'nexxen-patch' ),
				'description' => __( 'Plugin pages (WPvivid…) still use WordPress\'s default blue links, blue tabs and blue form controls, which clash with the uiXpress design. This recolours standard links, nav-tabs and checkboxes/radios to the neutral admin palette.', 'nexxen-patch' ),
			),
			'plugin-page-buttons'        => array(
				'label'       => __( 'Consistent buttons on plugin pages', 'nexxen-patch' ),
				'description' => __( 'WordPress-blue buttons ("Save Changes", "Re-run Setup Wizard"…) survive on plugin pages, sometimes with unreadable text where uiXpress half-restyles them. Primary buttons become the dark pill, secondary buttons the soft neutral, matching the rest of the interface.', 'nexxen-patch' ),
			),
			'themes-breathing-room'      => array(
				'label'       => __( 'Give theme cards breathing room', 'nexxen-patch' ),
				'description' => __( 'On the Themes screen the card footers are cramped: the active theme\'s name collides with the Customize button. This restores padding and stops the collision.', 'nexxen-patch' ),
			),
			'profile-menu-anchor'        => array(
				'label'       => __( 'Anchor the profile menu to the sidebar', 'nexxen-patch' ),
				'description' => __( 'The profile popup (bottom-left) is positioned by script into a zero-height wrapper, so it can land far from the profile row depending on window size and scroll. This pins it to the sidebar corner, just above its trigger.', 'nexxen-patch' ),
			),
			'novamira-pill-calm'         => array(
				'label'       => __( 'Calm the Novamira status pill', 'nexxen-patch' ),
				'description' => __( 'The bright red "Novamira ON" toolbar pill shouts louder than anything else in the bar. This restyles it as a quiet green chip; it stays visible and clickable.', 'nexxen-patch' ),
			),
			'sidebar-fade-off'           => array(
				'label'       => __( 'Remove the sidebar fade-out', 'nexxen-patch' ),
				'description' => __( 'uiXpress paints a gradient over the bottom of the sidebar menu, which makes the last items (JetEngine, Plugins…) look disabled. This removes the gradient so every item is fully readable.', 'nexxen-patch' ),
			),
		);
	}

	public function enabled( $fix_id ) {
		$disabled = get_option( self::OPTION, array() );
		return ! in_array( $fix_id, (array) $disabled, true );
	}

	public function boot() {
		$updater = new Nexxen_Patch\Updater();
		$updater->boot();

		if ( ! is_admin() ) {
			return; // Admin-only plugin: zero footprint on the public site.
		}
		add_action( 'admin_menu', array( $this, 'register_settings_page' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( NEXXEN_PATCH_FILE ), array( $this, 'settings_link' ) );

		/*
		 * Every fix is calibrated to the uiXpress interface. If uiXpress is
		 * deactivated (or this plugin lands on a site without it), printing
		 * them would restyle a plain WordPress admin nobody asked to change —
		 * so the whole fix engine gates on uiXpress being active.
		 */
		if ( ! $this->uixpress_active() ) {
			return;
		}
		add_action( 'admin_print_styles', array( $this, 'print_fix_css' ), 9999 );
	}

	private function uixpress_active() {
		foreach ( (array) get_option( 'active_plugins', array() ) as $plugin ) {
			if ( false !== strpos( (string) $plugin, 'uixpress' ) ) {
				return true;
			}
		}
		return (bool) apply_filters( 'nexxen_patch_force_enable', false );
	}

	public function settings_link( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=nexxen-patch' ) ) . '">' . esc_html__( 'Settings', 'nexxen-patch' ) . '</a>' );
		return $links;
	}

	private function on_reset_clash_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen ) {
			return false;
		}
		$offenders = apply_filters( 'nexxen_patch_reset_clash_screens', array( 'core-framework', '_page_sq_' ) );
		foreach ( (array) $offenders as $needle ) {
			if ( false !== strpos( (string) $screen->id, $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * One inline style block, only the enabled fixes, printed on every admin
	 * screen. Inline because the whole block is under 1 KB — an extra HTTP
	 * request would cost more than it saves.
	 *
	 * Selector choice: everything targets WordPress-core ids (#wp-admin-bar-…)
	 * that uiXpress re-hosts unchanged, or uiXpress's two stable semantic
	 * hooks (.uixpress-isolation, .menu-expanded-overlay). No hashed or
	 * utility class names, so the rules survive uiXpress updates.
	 */
	public function print_fix_css() {
		$css = '';

		/*
		 * Core Framework's admin app ships an UNLAYERED css reset
		 * (div, ul, li … { padding:0; margin:0 }). uiXpress's entire styling
		 * lives inside CSS cascade layers, and unlayered rules beat layered
		 * ones regardless of specificity — so on Core Framework screens the
		 * reset flattens every uiXpress spacing utility and the sidebar
		 * collapses into icon-over-text soup. `revert-layer` from our own
		 * unlayered rule hands those properties back to the layered cascade,
		 * i.e. back to uiXpress. Scoped to uiXpress containers only, so Core
		 * Framework's own app is untouched.
		 */
		if ( $this->enabled( 'core-framework-reset-clash' ) && $this->on_reset_clash_screen() ) {
			$css .= '.uixpress-isolation.uixpress-isolation,.uixpress-isolation.uixpress-isolation *,.uixpress-isolation.uixpress-isolation ::before,.uixpress-isolation.uixpress-isolation ::after{'
				. 'padding:revert-layer;margin:revert-layer;list-style:revert-layer;border:revert-layer;}'
				/* Squirrly's Bootstrap forces .border{border:1px solid #dee2e6 !important};
				   uiXpress uses the same class name for a transparent border. Only an
				   !important at higher specificity can hand the property back. */
				. '.uixpress-isolation.uixpress-isolation *{border:revert-layer !important;}';
		}

		if ( $this->enabled( 'topbar-tidy' ) ) {
			$css .= '#uix-wp-toolbar-host .ab-item{white-space:nowrap;line-height:1.2;}'
				. '#uix-wp-toolbar-host li{display:flex;align-items:center;}'
				. '#uix-wp-toolbar-host ul.ab-top-menu{align-items:center;flex-wrap:nowrap;gap:2px;}'
				. '#uix-wp-toolbar-host ul.ab-top-menu>li>.ab-item{padding:5px 9px;border-radius:8px;display:flex;align-items:center;gap:5px;}'
				. '#uix-wp-toolbar-host ul.ab-top-menu>li>.ab-item:hover{background:#f2f2f4;}';
		}

		if ( $this->enabled( 'topbar-dropdowns' ) ) {
			/*
			 * The wrapper hugs the trigger (top:100%) and carries the visual
			 * 8px offset as HOVERABLE padding — a gap made with margin/top
			 * created a dead zone that closed the menu while the pointer
			 * crossed it. The card look lives on the inner .ab-submenu.
			 */
			$css .= '#uix-wp-toolbar-host li.menupop{position:relative;}'
				. '#uix-wp-toolbar-host .ab-sub-wrapper{position:absolute;top:100%;inset-inline-start:0;padding-top:8px;min-width:200px;z-index:99999;}'
				. '#uix-wp-toolbar-host .ab-submenu{display:block;background:#fff;border-radius:10px;'
				. 'box-shadow:0 12px 34px -10px rgba(16,18,25,.28);padding:6px;}'
				. '#uix-wp-toolbar-host .ab-submenu li{display:block;margin:0;padding:0;}'
				. '#uix-wp-toolbar-host .ab-sub-wrapper ul{margin:0;list-style:none;text-indent:0;}'
				/* The native (empty) arrow span nudges menupop labels sideways; we draw our own chevron. */
				. '#uix-wp-toolbar-host .wp-admin-bar-arrow{display:none;}'
				. '#uix-wp-toolbar-host .ab-submenu .ab-item{display:flex;align-items:center;'
				. 'padding:7px 10px !important;margin:0 !important;text-indent:0;border-radius:7px;white-space:nowrap;justify-content:flex-start;}'
				/* Discoverability arrows, in the interface's quiet zinc. */
				. '#uix-wp-toolbar-host ul.ab-top-menu>li.menupop>.ab-item::after{content:"\\2304";font-size:10px;line-height:1;'
				. 'color:#a1a1aa;margin-inline-start:4px;margin-top:-4px;}'
				. '#uix-wp-toolbar-host .ab-submenu li.menupop>.ab-item::after{content:"\\203A";font-size:14px;line-height:1;'
				. 'color:#a1a1aa;margin-inline-start:auto;padding-inline-start:14px;}'
				. '#uix-wp-toolbar-host .ab-submenu .ab-item:hover{background:#f2f2f4;}'
				. '#uix-wp-toolbar-host .ab-submenu li.menupop{position:relative;}'
				. '#uix-wp-toolbar-host .ab-submenu .menupop>.ab-sub-wrapper{position:absolute;top:-6px;inset-inline-start:100%;'
				. 'padding:0 0 0 8px;min-width:190px;}'
				. '#uix-wp-toolbar-host .ab-submenu .ab-submenu{background:#fff;border-radius:10px;'
				. 'box-shadow:0 12px 34px -10px rgba(16,18,25,.28);padding:6px;}';
		}

		if ( $this->enabled( 'topbar-icons' ) ) {
			$css .= '#uix-wp-toolbar-host .ab-item img{width:16px;height:16px;object-fit:contain;flex:none;}'
				. '#uix-wp-toolbar-host #wp-admin-bar-command-palette .ab-item{background:transparent;font-size:12px;color:#71717a;letter-spacing:.02em;}'
				. '.uixpress-isolation [id^="reka-dropdown-menu-trigger"]{width:34px;height:34px;min-height:34px;padding:8px;align-self:center;}'
				. '.uixpress-isolation [id^="reka-dropdown-menu-trigger"] svg{width:18px;height:18px;}'
				. '.uixpress-isolation button[aria-label="Open search"]{background:transparent !important;border-color:transparent !important;box-shadow:none !important;border-radius:8px;}'
				. '.uixpress-isolation button[aria-label="Open search"]:hover{background:#f2f2f4 !important;}'
				. '.uixpress-isolation button:focus:not(:focus-visible){outline:none !important;box-shadow:none !important;}'
				. '.uixpress-isolation button:focus-visible{outline:none !important;box-shadow:0 0 0 2px rgba(24,24,27,.25) !important;}'
				. '.uixpress-isolation input:focus,.uixpress-isolation input:focus-visible{outline:none !important;box-shadow:none !important;}';
		}

		if ( $this->enabled( 'plugin-page-palette' ) ) {
			/* Scoped to .wrap: classic plugin pages all use it; uiXpress's own
			   screens (plugin manager…) do not, so their styled icons and links
			   keep their intended colours. */
			$css .= '#wpbody-content .wrap a:not(.button):not(.nav-tab):not(.page-title-action){color:#3b3b40;}'
				. '#wpbody-content .wrap a:not(.button):not(.nav-tab):not(.page-title-action):hover{color:#111114;}'
				. '#wpcontent input[type=checkbox],#wpcontent input[type=radio]{accent-color:#232327;}'
				. '.nav-tab-wrapper{border-bottom:1px solid #e4e4e7;display:flex;gap:2px;flex-wrap:wrap;padding:0 0 6px;}'
				. '.nav-tab{border:0;background:transparent;border-radius:8px;padding:7px 13px;color:#52525b;margin:0;font-size:13px;}'
				. '.nav-tab:hover{background:#f4f4f5;color:#18181b;}'
				. '.nav-tab-active,.nav-tab-active:hover{background:#e4e4e7;color:#18181b;}'
				/* TranslatePress: its blue "Translate Site" CTA becomes the dark action pill,
				   and its dimensionless SVG logo gets a real size instead of rendering broken. */
				. '.nav-tab.trp-translation-editor,.nav-tab.trp-translation-editor:hover{background:#18181b !important;color:#fff !important;}'
				. '#wpbody-content img[src*="translatepress"][src$=".svg"]{width:190px;height:36px;object-fit:contain;}'
				/* Site Health: neutral accents instead of WordPress blue. */
				. '.health-check-tabs-wrapper .health-check-tab.active{border-bottom-color:#18181b;color:#18181b;}'
				. '.site-health-issues-wrapper .badge{border-color:#d4d4d8;color:#3f3f46;}';
		}

		if ( $this->enabled( 'plugin-page-buttons' ) ) {
			$css .= '#wpbody-content{--trp-settings-accent:#1c1c1f;}'
				. '#wpbody-content .wrap .button-primary,#wpbody-content .wrap input.button-primary,#wpbody-content .wrap .trp-submit-btn{'
				. 'background:#1c1c1f !important;border-color:#1c1c1f !important;color:#fff !important;'
				. 'border-radius:8px;text-shadow:none;box-shadow:none;}'
				. '#wpbody-content .wrap .button-primary:hover{background:#3a3a3f !important;border-color:#3a3a3f !important;}'
				. '#wpbody-content .wrap .button:not(.button-primary){background:#f2f2f4 !important;border-color:#f2f2f4 !important;'
				. 'color:#232327 !important;border-radius:8px;box-shadow:none;}'
				. '#wpbody-content .wrap .button:not(.button-primary):hover{background:#e8e8ec !important;color:#111114 !important;}';
		}

		if ( $this->enabled( 'themes-breathing-room' ) ) {
			$css .= '.theme-browser .theme .theme-name{height:auto;padding:12px 14px;font-size:13.5px;}'
				. '.theme-browser .theme.active .theme-name{padding-inline-end:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}'
				. '.theme-browser .theme .theme-actions{padding:8px 10px;}';
		}

		if ( $this->enabled( 'logo-rounding' ) ) {
			$css .= '.uixpress-isolation a.h-10>img.h-full{border-radius:9px;}';
		}

		if ( $this->enabled( 'notice-polish' ) ) {
			$css .= '#wpbody-content .notice .button,#wpbody-content .notice .button-primary,#wpbody-content .notice button{'
				. 'background:#1c1c1f !important;color:#fff !important;border:0 !important;border-radius:8px;'
				. 'padding:6px 14px;line-height:1.5;text-shadow:none;}'
				. '#wpbody-content .notice .button:hover{background:#3a3a3f !important;color:#fff !important;}';
		}

		if ( $this->enabled( 'profile-menu-anchor' ) ) {
			$css .= '.uixpress-isolation div[class*="shadow-lg"][style*="top"]:has(a[href*="profile.php"]){'
				. 'position:fixed !important;top:auto !important;bottom:76px !important;left:11px !important;right:auto !important;}';
		}

		if ( $this->enabled( 'novamira-pill-calm' ) ) {
			$css .= '#uix-wp-toolbar-host #wp-admin-bar-novamira-mcp-status.novamira-mcp-on>.ab-item{'
				. 'background:#e7f5ee !important;color:#14683c !important;border-radius:8px;font-weight:500;}';
		}

		if ( $this->enabled( 'sidebar-fade-off' ) ) {
			$css .= '.menu-expanded-overlay{display:none !important;}';
		}

		if ( $css ) {
			echo '<style id="nexxen-patch">' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	/* -----------------------------------------------------------------
	 * Settings page: one checkbox per fix.
	 * -------------------------------------------------------------- */

	public function register_settings_page() {
		add_options_page(
			__( 'Nexxen Patch', 'nexxen-patch' ),
			__( 'Nexxen Patch', 'nexxen-patch' ),
			'manage_options',
			'nexxen-patch',
			array( $this, 'render_settings_page' )
		);
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['nexxen_patch_save'] ) && check_admin_referer( 'nexxen_patch_save' ) ) {
			$on       = isset( $_POST['nexxen_patch_on'] ) ? array_map( 'sanitize_key', (array) $_POST['nexxen_patch_on'] ) : array();
			$disabled = array_values( array_diff( array_keys( $this->fixes() ), $on ) );
			update_option( self::OPTION, $disabled, false );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Saved. Reload any admin page to see the change.', 'nexxen-patch' ) . '</p></div>';
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Nexxen Patch', 'nexxen-patch' ) . '</h1>';
		echo '<p>' . esc_html__( 'Visual fixes for wp-admin. Everything is on by default; untick a fix to switch it off. Fixes only load in the admin, never on the public site.', 'nexxen-patch' ) . '</p>';

		/*
		 * uiXpress replaces the Plugins screen with its own, hiding the
		 * "Check for updates" row link — so the update check also lives here,
		 * where it is always reachable. Same handler, same nonce.
		 */
		$check_url = wp_nonce_url( add_query_arg( 'nexxen-check-updates', '1', admin_url( 'plugins.php' ) ), 'nexxen-check-updates' );
		echo '<p><strong>' . esc_html( sprintf( __( 'Version %s', 'nexxen-patch' ), NEXXEN_PATCH_VERSION ) ) . '</strong> · ';
		echo '<a href="' . esc_url( $check_url ) . '">' . esc_html__( 'Check for updates now', 'nexxen-patch' ) . '</a></p>';
		echo '<form method="post">';
		wp_nonce_field( 'nexxen_patch_save' );
		echo '<table class="form-table" role="presentation">';
		foreach ( $this->fixes() as $id => $fix ) {
			echo '<tr><th scope="row"><label for="nexxen-patch-' . esc_attr( $id ) . '">' . esc_html( $fix['label'] ) . '</label></th><td>';
			echo '<input type="checkbox" name="nexxen_patch_on[]" id="nexxen-patch-' . esc_attr( $id ) . '" value="' . esc_attr( $id ) . '" ' . checked( $this->enabled( $id ), true, false ) . '> ';
			echo '<span class="description">' . esc_html( $fix['description'] ) . '</span>';
			echo '</td></tr>';
		}
		echo '</table>';
		echo '<p><input type="submit" name="nexxen_patch_save" class="button button-primary" value="' . esc_attr__( 'Save', 'nexxen-patch' ) . '"></p>';
		echo '</form></div>';
	}
}
