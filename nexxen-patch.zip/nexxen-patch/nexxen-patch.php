<?php
/**
 * Plugin Name: Nexxen Patch
 * Plugin URI: https://nexxenstudio.com/
 * Description: Fixes visual defects that admin-theme and framework plugins cause in wp-admin (currently: uiXpress + Core Framework conflicts). Each fix is a toggle under Settings → Nexxen Patch; all fixes are on by default. Fixes live here so they survive updates of the plugins they patch.
 * Version: 1.0.0
 * Requires at least: 6.5
 * Requires PHP: 7.4
 * Author: Nexxen Studio
 * Author URI: https://nexxenstudio.com/
 * License: GPL-2.0-or-later
 * Text Domain: nexxen-patch
 */

defined( 'ABSPATH' ) || exit;

define( 'NEXXEN_PATCH_VERSION', '1.0.0' );
define( 'NEXXEN_PATCH_FILE', __FILE__ );

require_once __DIR__ . '/src/Updater.php';

add_action( 'plugins_loaded', static function () {
	Nexxen_Patch_Plugin::instance()->boot();
}, 5 );

final class Nexxen_Patch_Plugin {

	const OPTION = 'nexxen_patch_disabled'; // Array of fix ids the operator switched OFF.

	private static $instance;

	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * The fix registry. Adding a future fix = one entry here plus its CSS in
	 * print_fix_css() (or a scoped hook). Everything is admin-only; nothing in
	 * this plugin ever loads on the public front end.
	 */
	public function fixes() {
		return array(
			'core-framework-reset-clash' => array(
				'label'       => __( 'Repair the uiXpress sidebar on Core Framework screens', 'nexxen-patch' ),
				'description' => __( 'Core Framework ships an unlayered CSS reset that flattens uiXpress\'s layered spacing utilities, collapsing the sidebar (icons drawn over the menu labels). This restores the layered styles inside uiXpress containers on those screens.', 'nexxen-patch' ),
			),
			'topbar-tidy'                => array(
				'label'       => __( 'Tidy the top toolbar', 'nexxen-patch' ),
				'description' => __( 'Third-party toolbar items wrap onto two lines at uneven heights inside the uiXpress top bar. This keeps every item on one line at one height.', 'nexxen-patch' ),
			),
			'novamira-pill-calm'         => array(
				'label'       => __( 'Calm the Novamira status pill', 'nexxen-patch' ),
				'description' => __( 'The bright red "Novamira ON" toolbar pill shouts louder than anything else in the bar. This restyles it as a quiet green chip; it stays visible and clickable.', 'nexxen-patch' ),
			),
			'sidebar-fade-off'           => array(
				'label'       => __( 'Remove the sidebar fade-out', 'nexxen-patch' ),
				'description' => __( 'uiXpress paints a gradient over the bottom of the sidebar menu, which makes the last items (JetEngine, Plugins…) look disabled. This removes the gradient so every item is fully readable.', 'nexxen-patch' ),
			),
		);
	}

	public function enabled( $fix_id ) {
		$disabled = get_option( self::OPTION, array() );
		return ! in_array( $fix_id, (array) $disabled, true );
	}

	public function boot() {
		$updater = new Nexxen_Patch\Updater();
		$updater->boot();

		if ( ! is_admin() ) {
			return; // Admin-only plugin: zero footprint on the public site.
		}
		add_action( 'admin_print_styles', array( $this, 'print_fix_css' ), 9999 );
		add_action( 'admin_menu', array( $this, 'register_settings_page' ) );
	}

	private function on_core_framework_screen() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		return $screen && false !== strpos( (string) $screen->id, 'core-framework' );
	}

	/**
	 * One inline style block, only the enabled fixes, printed on every admin
	 * screen. Inline because the whole block is under 1 KB — an extra HTTP
	 * request would cost more than it saves.
	 *
	 * Selector choice: everything targets WordPress-core ids (#wp-admin-bar-…)
	 * that uiXpress re-hosts unchanged, or uiXpress's two stable semantic
	 * hooks (.uixpress-isolation, .menu-expanded-overlay). No hashed or
	 * utility class names, so the rules survive uiXpress updates.
	 */
	public function print_fix_css() {
		$css = '';

		/*
		 * Core Framework's admin app ships an UNLAYERED css reset
		 * (div, ul, li … { padding:0; margin:0 }). uiXpress's entire styling
		 * lives inside CSS cascade layers, and unlayered rules beat layered
		 * ones regardless of specificity — so on Core Framework screens the
		 * reset flattens every uiXpress spacing utility and the sidebar
		 * collapses into icon-over-text soup. `revert-layer` from our own
		 * unlayered rule hands those properties back to the layered cascade,
		 * i.e. back to uiXpress. Scoped to uiXpress containers only, so Core
		 * Framework's own app is untouched.
		 */
		if ( $this->enabled( 'core-framework-reset-clash' ) && $this->on_core_framework_screen() ) {
			$css .= '.uixpress-isolation,.uixpress-isolation *,.uixpress-isolation ::before,.uixpress-isolation ::after{'
				. 'padding:revert-layer;margin:revert-layer;list-style:revert-layer;border:revert-layer;}';
		}

		if ( $this->enabled( 'topbar-tidy' ) ) {
			$css .= '#uix-wp-toolbar-host .ab-item{white-space:nowrap;line-height:1.2;}'
				. '#uix-wp-toolbar-host li{display:flex;align-items:center;}'
				. '#uix-wp-toolbar-host ul.ab-top-menu{align-items:center;flex-wrap:nowrap;}';
		}

		if ( $this->enabled( 'novamira-pill-calm' ) ) {
			$css .= '#uix-wp-toolbar-host #wp-admin-bar-novamira-mcp-status.novamira-mcp-on>.ab-item{'
				. 'background:#e7f5ee !important;color:#14683c !important;border-radius:8px;font-weight:500;}';
		}

		if ( $this->enabled( 'sidebar-fade-off' ) ) {
			$css .= '.menu-expanded-overlay{display:none !important;}';
		}

		if ( $css ) {
			echo '<style id="nexxen-patch">' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	/* -----------------------------------------------------------------
	 * Settings page: one checkbox per fix.
	 * -------------------------------------------------------------- */

	public function register_settings_page() {
		add_options_page(
			__( 'Nexxen Patch', 'nexxen-patch' ),
			__( 'Nexxen Patch', 'nexxen-patch' ),
			'manage_options',
			'nexxen-patch',
			array( $this, 'render_settings_page' )
		);
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['nexxen_patch_save'] ) && check_admin_referer( 'nexxen_patch_save' ) ) {
			$on       = isset( $_POST['nexxen_patch_on'] ) ? array_map( 'sanitize_key', (array) $_POST['nexxen_patch_on'] ) : array();
			$disabled = array_values( array_diff( array_keys( $this->fixes() ), $on ) );
			update_option( self::OPTION, $disabled, false );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Saved. Reload any admin page to see the change.', 'nexxen-patch' ) . '</p></div>';
		}

		echo '<div class="wrap"><h1>' . esc_html__( 'Nexxen Patch', 'nexxen-patch' ) . '</h1>';
		echo '<p>' . esc_html__( 'Visual fixes for wp-admin. Everything is on by default; untick a fix to switch it off. Fixes only load in the admin, never on the public site.', 'nexxen-patch' ) . '</p>';
		echo '<form method="post">';
		wp_nonce_field( 'nexxen_patch_save' );
		echo '<table class="form-table" role="presentation">';
		foreach ( $this->fixes() as $id => $fix ) {
			echo '<tr><th scope="row"><label for="nexxen-patch-' . esc_attr( $id ) . '">' . esc_html( $fix['label'] ) . '</label></th><td>';
			echo '<input type="checkbox" name="nexxen_patch_on[]" id="nexxen-patch-' . esc_attr( $id ) . '" value="' . esc_attr( $id ) . '" ' . checked( $this->enabled( $id ), true, false ) . '> ';
			echo '<span class="description">' . esc_html( $fix['description'] ) . '</span>';
			echo '</td></tr>';
		}
		echo '</table>';
		echo '<p><input type="submit" name="nexxen_patch_save" class="button button-primary" value="' . esc_attr__( 'Save', 'nexxen-patch' ) . '"></p>';
		echo '</form></div>';
	}
}
