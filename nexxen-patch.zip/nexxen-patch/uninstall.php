<?php
/**
 * Nexxen Patch uninstall: remove the options this plugin stores.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'nexxen_patch_disabled' );
delete_site_transient( 'nexxen_patch_update_manifest' );
